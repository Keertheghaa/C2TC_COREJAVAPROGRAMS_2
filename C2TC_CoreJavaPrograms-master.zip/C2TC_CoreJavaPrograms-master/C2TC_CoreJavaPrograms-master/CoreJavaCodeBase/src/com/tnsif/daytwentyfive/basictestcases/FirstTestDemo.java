//Program to demonstrate first test case
package com.tnsif.daytwentyfive.basictestcases;

import org.junit.jupiter.api.Test;

public class FirstTestDemo {
	@Test
	void firstTest() {
		System.out.println("Hello");
	}
}
