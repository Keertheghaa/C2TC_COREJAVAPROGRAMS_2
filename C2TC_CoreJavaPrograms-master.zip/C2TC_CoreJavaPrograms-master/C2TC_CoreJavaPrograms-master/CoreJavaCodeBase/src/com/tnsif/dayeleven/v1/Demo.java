//Program without exception handling
package com.tnsif.dayeleven.v1;
public class Demo {

	public static void main(String[] args) {
		System.out.println("the program continues....");
		int data=100/0;
	}
	
}
