//Program to demonstrate method overriding - Runtime Polymorphism
package com.tnsif.dayseven.overriding;

//subclass
public class HDFC extends RBI {
	@Override
	public float getRateOfInterest() {
		return 6.8f;
	}

}